import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { internal } from "./_generated/api";
export const store = mutation({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new Error("Called storeUser without authentication present");
    }

    // Check if we've already stored this identity before.
    // Note: If you don't want to define an index right away, you can use
    // ctx.db.query("users")
    //  .filter(q => q.eq(q.field("tokenIdentifier"), identity.tokenIdentifier))
    //  .unique();
    const user= await ctx.db
      .query("users")
      .withIndex("by_token", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier),
      )
      .unique();
    if (user !== null) {
      // If we've seen this identity before but the name has changed, patch the value.
      if (user.name !== identity.name) {
        await ctx.db.patch(user._id, { name: identity.name , updatedAt: Date.now() });
      }
      return user._id;
    }
    // If it's a new identity, create a new `User`.
    return await ctx.db.insert("users", {
      name: identity.name ?? "Anonymous",
      tokenIdentifier: identity.tokenIdentifier,
      email: identity.email ?? "",
      imageUrl: identity.pictureUrl,
      hasCompletedOnboarding:false,
      freeEventsCreated:0,
       createdAt: Date.now(),
        updatedAt: Date.now()
    });
  },
});


export const getCurrentUser = query({
    handler:async (ctx)=>{
        const identity = await ctx.auth.getUserIdentity();
        if(!identity){
            return null;
        }

        const user = await ctx.db.query("users")
        .withIndex("by_token", (q) =>
            q.eq("tokenIdentifier", identity.tokenIdentifier)
        )
        .unique();

        if(!user){
            throw new Error("User not found in database");
        }
        return user;
    }
})

//api for user Onboarding 

export const completeOnboarding = mutation({
  args:{
    location: v.object({
      city:v.string(),
      state:v.string(),
      country:v.string()
    }),
    interests:v.array(v.string()),
  },
   handler: async (ctx, args) => {
    const user = await ctx.runQuery(internal.users.getCurrentUser);

    //update
    await ctx.db.patch(user._id, {
      location: args.location,
      interests: args.interests,
      hasCompletedOnboarding: true,
      updatedAt: Date.now(),
    });

    return user._id;
  },
})